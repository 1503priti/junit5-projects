package com.codesnippet.ecomassistant.Service;

import org.springframework.stereotype.Service;

@Service
public class EcomUtilityService {
    public EcomUtilityService() {
        System.out.println();
    }
}
