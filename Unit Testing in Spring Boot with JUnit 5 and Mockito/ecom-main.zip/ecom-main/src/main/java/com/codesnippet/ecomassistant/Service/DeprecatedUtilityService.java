package com.codesnippet.ecomassistant.Service;

import org.springframework.stereotype.Service;

@Service
public class DeprecatedUtilityService {
    public DeprecatedUtilityService() {
        System.out.println("DeprecatedUtilityService");
    }
}
