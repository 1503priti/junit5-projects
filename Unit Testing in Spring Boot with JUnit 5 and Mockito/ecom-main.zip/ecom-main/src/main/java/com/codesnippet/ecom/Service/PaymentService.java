package com.codesnippet.ecom.Service;

public interface PaymentService {
    void processPayment(double amount);
}
